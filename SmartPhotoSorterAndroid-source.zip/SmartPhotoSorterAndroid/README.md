# Smart Photo Sorter — Android native project

This is an Android Studio project (Kotlin) for the Android-first version of the photo sorter described in `photo-sorter-prompt.pdf`.

## Important build status

This environment does not contain the Android SDK, Android Gradle Plugin cache, or Gradle executable, so I cannot compile, sign, or truthfully provide a tested APK from this session. Open this project in Android Studio on a computer with Android SDK Platform 35 and JDK 17, let Gradle sync, then use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

## Implemented in this first Android prototype

- Native Android activity; no web server and no cloud photo upload.
- Android Storage Access Framework folder selection with persisted read/write permission.
- Recursive local inventory of supported image/video files.
- SHA-256 exact duplicate detection; keeps the largest file and copies the others into `_Review/duplicates`.
- Image dimensions, file size, MIME type, modified timestamp, and video duration metadata.
- On-device ML Kit OCR. OCR text is evaluated in memory only and is not written to CSV, logs, or the UI.
- Conservative routing for some sensitive-ID/card keywords and number patterns, receipts, text-heavy images, screenshots, and screen recordings.
- Ambiguous visual items go to `_Review/needs_review` rather than being guessed into a visual category.
- Copies sorted files into `SmartPhotoSorter_Output`; original files are not moved, renamed, or deleted.
- `sorted.csv`, `duplicates.csv`, folder counts, and ZIP export.

## Not yet implemented / not validated

This is a first native prototype, not the fully validated 16-class AI sorter from the specification:

- No bundled CLIP/TFLite visual model yet. The app therefore does **not** reliably identify selfies, family, pets, food, travel, city scenes, memes, etc.; ambiguous images are routed to review.
- Perceptual-hash near-duplicate detection and pixel verification are not implemented yet; only byte-identical SHA-256 duplicates are detected.
- OCR-based sensitive-document detection is heuristic and must not be treated as a guarantee. Review the sensitive folder manually and do not rely on it as a security control.
- HEIC/HEIF decoding/OCR depends on Android device codec support and has not been tested across devices.
- No actual 200-photo trial, accuracy measurement, 1,000-file stress test, or physical-device test has been run.
- The current dashboard is an in-app native summary, not a separate browser dashboard.

## Build requirements

- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Internet for the first Gradle dependency sync. Photo content itself is processed locally. ML Kit's bundled OCR dependency is used; first-time model behavior should be checked on the target device.

## Build APK

1. Extract the project ZIP.
2. Open the `SmartPhotoSorterAndroid` folder in Android Studio.
3. Wait for Gradle sync and install any requested Android SDK components.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install the generated debug APK on your Android phone.

## Use

1. Open Smart Photo Sorter.
2. Tap **Choose gallery folder** and select the folder containing the photos/videos. Grant access.
3. Tap **Scan and sort**. Keep the app open during processing.
4. Find copied output under `SmartPhotoSorter_Output` inside the selected folder.
5. Use **Export sorted ZIP** to create a ZIP through Android's save dialog.

## Safety notes

- The app only reads originals and creates copies. It does not call delete, rename, or move on source media.
- Output is written to a new `SmartPhotoSorter_Output` folder in the selected directory.
- Do not select the whole device root if a narrower `DCIM`, `Pictures`, or gallery export folder is sufficient.
- The ZIP and output folders may contain sensitive material. Store/share them carefully.

## Cloud build option (if you only have an Android phone)

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. If you upload the project contents to a GitHub repository and enable Actions, it can build the debug APK on a GitHub-hosted Linux runner. Open the repository's **Actions → Build Android APK** workflow, run it (or push to `main`), then open the successful run and download the `SmartPhotoSorter-debug-apk` artifact. GitHub may require repository Actions permissions to be enabled. This workflow is a convenience; it has not been executed from this environment.
