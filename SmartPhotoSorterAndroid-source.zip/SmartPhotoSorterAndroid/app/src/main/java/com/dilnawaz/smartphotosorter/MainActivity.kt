package com.dilnawaz.smartphotosorter

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var summary: TextView
    private lateinit var progress: ProgressBar
    private lateinit var chooseButton: Button
    private lateinit var scanButton: Button
    private lateinit var zipButton: Button
    private var sourceTree: Uri? = null
    private var outputDir: DocumentFile? = null
    private var lastReport = ""

    private val folders = listOf(
        "Selfies", "People & family", "Pets & animals", "Food & drinks",
        "Travel & nature", "City & nights out", "Home & everyday",
        "Documents & receipts", "Memes & saved posts", "Other screenshots",
        "Photos with text", "Sensitive IDs & cards", "Talking & selfie videos",
        "Travel clips", "Screen recordings", "Everyday clips"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        sourceTree = getPreferences(MODE_PRIVATE).getString("tree", null)?.let(Uri::parse)
        if (sourceTree != null) status.text = "Gallery folder remembered. Tap Scan gallery to continue."
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply {
            text = "Smart Photo Sorter"
            textSize = 27f
            setTextColor(0xFF17243A.toInt())
            setPadding(0, 8, 0, 8)
        }
        val intro = TextView(this).apply {
            text = "Private, on-device gallery organiser. Your originals are never moved, renamed or deleted."
            textSize = 15f
            setTextColor(0xFF526078.toInt())
            setPadding(0, 0, 0, 18)
        }
        chooseButton = Button(this).apply { text = "1. Choose gallery folder"; setOnClickListener { chooseFolder() } }
        scanButton = Button(this).apply { text = "2. Scan and sort"; isEnabled = sourceTree != null; setOnClickListener { startScan() } }
        zipButton = Button(this).apply { text = "Export sorted ZIP"; isEnabled = false; setOnClickListener { exportZip() } }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0; visibility = ProgressBar.GONE
        }
        status = TextView(this).apply {
            text = "Choose the folder that contains your photos and videos. For privacy, select the narrowest suitable gallery folder."
            textSize = 14f; setTextColor(0xFF344054.toInt()); setPadding(0, 18, 0, 14)
        }
        summary = TextView(this).apply {
            textSize = 14f; setTextColor(0xFF17243A.toInt()); setPadding(0, 12, 0, 12)
        }
        val privacy = TextView(this).apply {
            text = "Privacy: OCR text and detected ID/card numbers are never saved to reports or displayed. Sensitive items are counted and copied to a hidden-by-default category. Processing is local; ML Kit may download its on-device OCR model the first time."
            textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(0, 18, 0, 8)
        }
        content.addView(heading); content.addView(intro); content.addView(chooseButton)
        content.addView(scanButton); content.addView(zipButton); content.addView(progress)
        content.addView(status); content.addView(summary); content.addView(privacy)
        scroller.addView(content)
        outer.addView(scroller, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(outer)
    }

    private fun chooseFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_TREE)
    }

    @Deprecated("Using the Storage Access Framework result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_TREE && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(uri, flags)
            sourceTree = uri
            getPreferences(MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
            scanButton.isEnabled = true
            status.text = "Gallery folder selected. Originals will remain untouched."
        } else if (requestCode == REQUEST_ZIP && resultCode == Activity.RESULT_OK) {
            data?.data?.let(::exportZipTo)
        }
    }

    private fun startScan() {
        val uri = sourceTree ?: return
        chooseButton.isEnabled = false; scanButton.isEnabled = false; zipButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE; progress.progress = 0
        summary.text = ""
        status.text = "Preparing local scan…"
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val root = DocumentFile.fromTreeUri(this@MainActivity, uri) ?: error("Cannot open selected folder")
                val out = root.findFile("SmartPhotoSorter_Output") ?: root.createDirectory("SmartPhotoSorter_Output")
                    ?: error("Cannot create output folder")
                outputDir = out
                val candidates = mutableListOf<DocumentFile>()
                collectFiles(root, out.uri, candidates)
                val records = mutableListOf<Record>()
                var errors = 0
                candidates.forEachIndexed { index, file ->
                    try {
                        val hash = sha256(file)
                        val mime = file.type ?: "application/octet-stream"
                        val isVideo = mime.startsWith("video/") || file.name.orEmpty().substringAfterLast('.', "").lowercase() in VIDEO_EXT
                        val size = file.length()
                        val dimensions = if (!isVideo && mime.startsWith("image/")) imageDimensions(file.uri) else Pair(0, 0)
                        val duration = if (isVideo) videoDuration(file.uri) else 0L
                        records.add(Record(file, hash, size, mime, isVideo, dimensions.first, dimensions.second, duration))
                    } catch (_: Exception) { errors++ }
                    if (index % 10 == 0 || index == candidates.lastIndex) {
                        withContext(Dispatchers.Main) {
                            progress.progress = if (candidates.isEmpty()) 0 else ((index + 1) * 35 / candidates.size)
                            status.text = "Inventory: ${index + 1} / ${candidates.size} files"
                        }
                    }
                }
                val groups = records.groupBy { it.hash }
                val duplicateRecords = mutableListOf<Record>()
                val uniqueRecords = mutableListOf<Record>()
                groups.values.forEach { group ->
                    val keep = group.maxByOrNull { it.size }!!
                    uniqueRecords.add(keep)
                    duplicateRecords.addAll(group.filter { it !== keep })
                }
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                val counts = (folders + "Needs review").associateWith { 0 }.toMutableMap()
                val sortedRows = mutableListOf<String>()
                val duplicateRows = mutableListOf<String>()
                val duplicateFolder = out.findFile("_Review")?.findFile("duplicates")
                    ?: (out.findFile("_Review") ?: out.createDirectory("_Review")!!).createDirectory("duplicates")!!
                duplicateRecords.forEach { record ->
                    copyInto(record.file, duplicateFolder)
                    duplicateRows.add(csv(record.file.name) + "," + record.hash + "," + record.size)
                }
                uniqueRecords.forEachIndexed { index, record ->
                    val category = classify(record, recognizer)
                    counts[category] = (counts[category] ?: 0) + 1
                    val target = if (category == "Needs review") {
                        val review = out.findFile("_Review") ?: out.createDirectory("_Review")!!
                        review.findFile("needs_review") ?: review.createDirectory("needs_review")!!
                    } else ensureFolder(out, category)
                    copyInto(record.file, target)
                    sortedRows.add(listOf(csv(record.file.name), csv(category), record.hash, record.size.toString(),
                        record.width.toString(), record.height.toString(), record.durationMs.toString(), record.file.lastModified().toString(), csv(record.mime)).joinToString(","))
                    if (index % 5 == 0 || index == uniqueRecords.lastIndex) {
                        withContext(Dispatchers.Main) {
                            progress.progress = 35 + if (uniqueRecords.isEmpty()) 0 else ((index + 1) * 60 / uniqueRecords.size)
                            status.text = "Classifying and copying: ${index + 1} / ${uniqueRecords.size}"
                        }
                    }
                }
                recognizer.close()
                writeText(out, "sorted.csv", "filename,folder,sha256,size_bytes,width,height,duration_ms,last_modified_epoch_ms,mime_type\n" + sortedRows.joinToString("\n"))
                writeText(out, "duplicates.csv", "filename,sha256,size_bytes\n" + duplicateRows.joinToString("\n"))
                val sensitive = counts["Sensitive IDs & cards"] ?: 0
                val report = buildString {
                    appendLine("Scanned files: ${candidates.size}")
                    appendLine("Successfully inventoried: ${records.size}")
                    appendLine("Unreadable/corrupt skipped: $errors")
                    appendLine("Exact duplicates copied to review: ${duplicateRecords.size}")
                    appendLine("Unique files sorted: ${uniqueRecords.size}")
                    appendLine("Sensitive IDs/cards (hidden): $sensitive")
                    appendLine("\nFolder counts:")
                    folders.forEach { appendLine("$it: ${counts[it]}") }
                    appendLine("\nOutput: SmartPhotoSorter_Output")
                }
                lastReport = report
                withContext(Dispatchers.Main) {
                    progress.progress = 100
                    status.text = "Finished. Your originals were not changed."
                    summary.text = report
                    chooseButton.isEnabled = true; scanButton.isEnabled = true; zipButton.isEnabled = true
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    status.text = "Scan stopped safely: ${e.message ?: "unknown error"}"
                    chooseButton.isEnabled = true; scanButton.isEnabled = true
                }
            }
        }
    }

    private fun collectFiles(folder: DocumentFile, outputUri: Uri, result: MutableList<DocumentFile>) {
        folder.listFiles().forEach { child ->
            if (child.uri == outputUri || child.name == "SmartPhotoSorter_Output") return@forEach
            if (child.isDirectory) collectFiles(child, outputUri, result)
            else if (child.isFile) {
                val mime = child.type.orEmpty().lowercase(Locale.ROOT)
                val ext = child.name.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)
                if (mime.startsWith("image/") || mime.startsWith("video/") || ext in IMAGE_EXT || ext in VIDEO_EXT) result.add(child)
            }
        }
    }

    private fun sha256(file: DocumentFile): String {
        val digest = MessageDigest.getInstance("SHA-256")
        contentResolver.openInputStream(file.uri).use { input ->
            requireNotNull(input) { "Cannot read ${file.name}" }
            val buffer = ByteArray(1024 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun imageDimensions(uri: Uri): Pair<Int, Int> {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, options) }
        return Pair(options.outWidth.coerceAtLeast(0), options.outHeight.coerceAtLeast(0))
    }

    private fun videoDuration(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { retriever.release() }
    }

    private fun classify(record: Record, recognizer: com.google.mlkit.vision.text.TextRecognizer): String {
        val name = record.file.name.orEmpty().lowercase(Locale.ROOT)
        if (record.isVideo) {
            return when {
                name.contains("screen") || name.contains("recording") -> "Screen recordings"
                else -> "Needs review"
            }
        }
        val ocr = try {
            val image = InputImage.fromFilePath(this, record.file.uri)
            Tasks.await(recognizer.process(image)).text
        } catch (_: Exception) { "" }
        val text = ocr.lowercase(Locale.ROOT)
        // OCR content is evaluated only in memory; it is never saved or logged.
        val sensitiveWords = listOf("aadhaar", "आधार", "permanent account number", "income tax department", "passport", "voter identity", "driving licence", "driving license", "debit card", "credit card", "account number", "ifsc")
        val numberLike = Regex("\\b\\d{12}\\b|\\b[A-Z]{5}[0-9]{4}[A-Z]\\b|\\b\\d{4}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}\\b").containsMatchIn(ocr)
        if (sensitiveWords.any { text.contains(it) } || numberLike) return "Sensitive IDs & cards"
        val receiptWords = listOf("invoice", "receipt", "total amount", "tax invoice", "booking", "ticket", "payment successful", "transaction id", "gstin")
        if (receiptWords.any { text.contains(it) }) return "Documents & receipts"
        if (name.contains("screenshot") || name.contains("screen_shot") || name.contains("scr_")) {
            return "Other screenshots"
        }
        if (text.length > 120) return "Photos with text"
        // No image-label model is bundled in this starter build. Ambiguous images go to review.
        return "Needs review"
    }

    private fun ensureFolder(root: DocumentFile, name: String): DocumentFile =
        root.findFile(name) ?: root.createDirectory(name) ?: error("Cannot create $name")

    private fun copyInto(source: DocumentFile, target: DocumentFile) {
        val original = source.name ?: "unnamed"
        var filename = original
        var suffix = 1
        while (target.findFile(filename) != null) {
            val dot = original.lastIndexOf('.')
            filename = if (dot > 0) original.substring(0, dot) + "_$suffix" + original.substring(dot) else "${original}_$suffix"
            suffix++
        }
        val dest = target.createFile(source.type ?: "application/octet-stream", filename) ?: error("Cannot create copy")
        contentResolver.openInputStream(source.uri).use { input ->
            contentResolver.openOutputStream(dest.uri).use { output ->
                requireNotNull(input).copyTo(requireNotNull(output), 1024 * 1024)
            }
        }
    }

    private fun writeText(root: DocumentFile, name: String, value: String) {
        val old = root.findFile(name); old?.delete()
        val file = root.createFile("text/csv", name) ?: error("Cannot write $name")
        contentResolver.openOutputStream(file.uri).use { it?.bufferedWriter()?.use { writer -> writer.write(value) } }
    }

    private fun csv(value: String?): String = "\"${(value ?: "").replace("\"", "\"\"")}\""

    private fun exportZip() {
        val out = outputDir ?: return
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"; putExtra(Intent.EXTRA_TITLE, "SmartPhotoSorter_Output.zip")
        }
        pendingZipRoot = out
        startActivityForResult(intent, REQUEST_ZIP)
    }

    private var pendingZipRoot: DocumentFile? = null

    private fun zipFolder(folder: DocumentFile, path: String, zip: ZipOutputStream) {
        folder.listFiles().forEach { child ->
            val name = child.name ?: "file"
            val entryPath = if (path.isEmpty()) name else "$path/$name"
            if (child.isDirectory) zipFolder(child, entryPath, zip)
            else {
                zip.putNextEntry(ZipEntry(entryPath))
                contentResolver.openInputStream(child.uri).use { it?.copyTo(zip, 1024 * 1024) }
                zip.closeEntry()
            }
        }
    }

    private fun exportZipTo(uri: Uri) {
        val root = pendingZipRoot ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                contentResolver.openOutputStream(uri).use { stream ->
                    ZipOutputStream(BufferedOutputStream(requireNotNull(stream))).use { zip -> zipFolder(root, "", zip) }
                }
                withContext(Dispatchers.Main) { status.text = "ZIP export completed." }
            } catch (e: Exception) { withContext(Dispatchers.Main) { status.text = "ZIP export failed: ${e.message}" } }
        }
    }

    data class Record(val file: DocumentFile, val hash: String, val size: Long, val mime: String,
                      val isVideo: Boolean, val width: Int, val height: Int, val durationMs: Long)

    companion object {
        private const val REQUEST_TREE = 101
        private const val REQUEST_ZIP = 102
        private val VIDEO_EXT = setOf("mp4", "mkv", "mov", "3gp", "webm", "avi", "m4v")
        private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif", "tif", "tiff")
    }
}
